def getpermutation(n,k):
    nums=list(range(1,n+1))
    result=""
    factorial=[1]*(n+1)
    
    
    for i in range(1,n+1):
        factorial[i]=factorial[i-1]*i

    
    
    k-=1
    
    for j in range(n,0,-1):
        index=k//factorial[j-1]
        result+=str(nums[index])
        nums.remove(nums[index])
        k%=factorial[j-1]
        
    return result

number_digits=int(input())
position_of_number=int(input())
print(getpermutation(number_digits,position_of_number))
